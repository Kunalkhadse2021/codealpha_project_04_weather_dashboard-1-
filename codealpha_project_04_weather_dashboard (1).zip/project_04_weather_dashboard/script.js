// LIVE WEATHER DASHBOARD - Open-Meteo API (no API key required)

const searchForm = document.getElementById("searchForm");
const cityInput = document.getElementById("cityInput");
const searchButton = document.getElementById("searchButton");
const statusMessage = document.getElementById("statusMessage");
const weatherContent = document.getElementById("weatherContent");

const weatherCodes = {
  0: ["Clear sky", "☀️"],
  1: ["Mainly clear", "🌤️"],
  2: ["Partly cloudy", "⛅"],
  3: ["Overcast", "☁️"],
  45: ["Fog", "🌫️"],
  48: ["Depositing rime fog", "🌫️"],
  51: ["Light drizzle", "🌦️"],
  53: ["Drizzle", "🌦️"],
  55: ["Dense drizzle", "🌧️"],
  56: ["Freezing drizzle", "🌧️"],
  57: ["Heavy freezing drizzle", "🌧️"],
  61: ["Light rain", "🌦️"],
  63: ["Rain", "🌧️"],
  65: ["Heavy rain", "🌧️"],
  66: ["Freezing rain", "🌧️"],
  67: ["Heavy freezing rain", "🌧️"],
  71: ["Light snow", "🌨️"],
  73: ["Snow", "🌨️"],
  75: ["Heavy snow", "❄️"],
  77: ["Snow grains", "🌨️"],
  80: ["Rain showers", "🌦️"],
  81: ["Rain showers", "🌧️"],
  82: ["Heavy rain showers", "⛈️"],
  85: ["Snow showers", "🌨️"],
  86: ["Heavy snow showers", "❄️"],
  95: ["Thunderstorm", "⛈️"],
  96: ["Thunderstorm with hail", "⛈️"],
  99: ["Severe thunderstorm", "⛈️"]
};

function getWeatherInfo(code) {
  return weatherCodes[code] || ["Weather unavailable", "🌡️"];
}

function showStatus(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.classList.toggle("error", isError);
}

function formatDay(dateString) {
  return new Date(`${dateString}T12:00:00`).toLocaleDateString(
    undefined,
    { weekday: "short" }
  );
}

async function getCoordinates(city) {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.search = new URLSearchParams({
    name: city,
    count: "1",
    language: "en",
    format: "json"
  });

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("City search service is unavailable. Please try again.");
  }

  const data = await response.json();
  if (!data.results || data.results.length === 0) {
    throw new Error("City not found. Check the spelling and try again.");
  }

  return data.results[0];
}

async function getForecast(latitude, longitude) {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.search = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min",
    forecast_days: "5",
    timezone: "auto"
  });

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Could not retrieve weather data. Please try again.");
  }

  return response.json();
}

function renderCurrentWeather(place, data) {
  const current = data.current;
  const [description, icon] = getWeatherInfo(current.weather_code);

  const placeParts = [place.name, place.admin1, place.country].filter(Boolean);
  document.getElementById("locationName").textContent = placeParts.join(", ");
  document.getElementById("currentDate").textContent =
    new Date(current.time).toLocaleString(undefined, {
      weekday: "long", day: "numeric", month: "long",
      hour: "numeric", minute: "2-digit"
    });

  document.getElementById("currentIcon").textContent = icon;
  document.getElementById("currentTemperature").textContent =
    `${Math.round(current.temperature_2m)}°`;
  document.getElementById("currentDescription").textContent = description;
  document.getElementById("feelsLike").textContent =
    `${Math.round(current.apparent_temperature)}°C`;
  document.getElementById("humidity").textContent =
    `${current.relative_humidity_2m}%`;
  document.getElementById("windSpeed").textContent =
    `${Math.round(current.wind_speed_10m)} km/h`;
}

function renderForecast(daily) {
  const forecastGrid = document.getElementById("forecastGrid");
  forecastGrid.innerHTML = "";

  daily.time.forEach((date, index) => {
    const [description, icon] = getWeatherInfo(daily.weather_code[index]);

    const card = document.createElement("article");
    card.className = "forecast-card";

    const day = document.createElement("p");
    day.className = "forecast-day";
    day.textContent = index === 0 ? "Today" : formatDay(date);

    const weatherIcon = document.createElement("div");
    weatherIcon.className = "forecast-icon";
    weatherIcon.textContent = icon;
    weatherIcon.setAttribute("aria-hidden", "true");

    const condition = document.createElement("p");
    condition.className = "forecast-condition";
    condition.textContent = description;

    const temperatures = document.createElement("p");
    temperatures.className = "forecast-temps";

    const high = document.createElement("span");
    high.textContent = `${Math.round(daily.temperature_2m_max[index])}°`;

    const low = document.createElement("span");
    low.textContent = `${Math.round(daily.temperature_2m_min[index])}°`;

    temperatures.append(high, low);
    card.append(day, weatherIcon, condition, temperatures);
    forecastGrid.appendChild(card);
  });
}

async function searchWeather(city) {
  searchButton.disabled = true;
  searchButton.textContent = "Loading...";
  weatherContent.hidden = true;
  showStatus("Getting the latest weather...");

  try {
    const place = await getCoordinates(city);
    const weather = await getForecast(place.latitude, place.longitude);

    renderCurrentWeather(place, weather);
    renderForecast(weather.daily);

    weatherContent.hidden = false;
    showStatus(`Weather successfully loaded for ${place.name}.`);
  } catch (error) {
    showStatus(error.message || "Something went wrong. Please try again.", true);
  } finally {
    searchButton.disabled = false;
    searchButton.textContent = "Search";
  }
}

searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const city = cityInput.value.trim();

  if (!city) {
    showStatus("Please enter a city name.", true);
    cityInput.focus();
    return;
  }

  searchWeather(city);
});

// Load a default city when the page opens.
searchWeather("Pune");
