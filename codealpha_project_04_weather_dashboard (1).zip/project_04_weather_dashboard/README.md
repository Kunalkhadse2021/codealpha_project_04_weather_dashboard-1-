# Live Weather Dashboard with Fetch API

## CodeAlpha Project 04

A responsive weather website that searches for a city and displays current weather conditions and a five-day forecast.

## Features

- Search for a city by name
- Current temperature and feels-like temperature
- Weather description and emoji icon
- Humidity and wind speed
- Five-day forecast with daily high and low temperatures
- Loading, validation and error messages
- Responsive desktop and mobile layout
- Asynchronous JavaScript using fetch and async/await

## Technologies

- HTML5
- CSS3
- JavaScript
- Fetch API
- Open-Meteo Geocoding API
- Open-Meteo Forecast API

## Files

- `index.html` — dashboard structure
- `style.css` — design and responsive layout
- `script.js` — API requests and dynamic weather rendering
- `README.md` — project documentation

## How to Run

1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. Open `index.html` using Live Server, or serve the folder with a local web server.
4. Search for a city such as Pune, Mumbai, Delhi or London.
5. View the current weather and five-day forecast.

An internet connection is required because the app retrieves live data from Open-Meteo. No API key is required for these public endpoints.

## API Endpoints

Geocoding:
`https://geocoding-api.open-meteo.com/v1/search`

Forecast:
`https://api.open-meteo.com/v1/forecast`

## Author

Kunal Khadse

## Conclusion

This project demonstrates asynchronous API requests, JSON data handling, input validation and dynamic DOM updates.
